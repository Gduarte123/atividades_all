const button = document.querySelector('button')

button.addEventListener('click', () =>{
    document.getElementById("minhaDiv").classList.add("classe1","classe2","classe3")
})
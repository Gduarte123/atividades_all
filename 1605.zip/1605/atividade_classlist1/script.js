function adicionarEstilo() {
    const quadrado = document.getElementById('quadrado');
    quadrado.classList.add('estilo-adicionado');
  }
  
  function removerEstilo() {
    const quadrado = document.getElementById('quadrado');
    quadrado.classList.remove('estilo-adicionado');
  }
  
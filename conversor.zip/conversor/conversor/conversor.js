function converter() {
    const valorDolar = parseFloat(document.getElementById('dolar').value);
    const taxaCambio = 5.67; // Exemplo: 1 USD = 5.67 BRL
  
    if (!isNaN(valorDolar)) {
      const valorReal = (valorDolar * taxaCambio).toFixed(2);
      document.getElementById('resultado').innerText =
        `US$ ${valorDolar.toFixed(2)} = R$ ${valorReal}`;
    } else {
      document.getElementById('resultado').innerText = "Por favor, insira um valor válido.";
    }
  }
  